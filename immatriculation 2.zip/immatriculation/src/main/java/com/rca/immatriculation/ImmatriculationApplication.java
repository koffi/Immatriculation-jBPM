package com.rca.immatriculation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImmatriculationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImmatriculationApplication.class, args);
	}

}
