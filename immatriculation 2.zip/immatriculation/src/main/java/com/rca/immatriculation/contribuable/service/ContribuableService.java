package com.rca.immatriculation.contribuable.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rca.immatriculation.contribuable.model.Contribuable;
import com.rca.immatriculation.contribuable.repository.ContribuableRepository;
import com.rca.immatriculation.contribuable.repository.ContribuableRepositoryImpl;

import java.util.List;

@Service
public class ContribuableService {

        @Autowired
        ContribuableRepository contribuableRepository;  
        @Autowired
        ContribuableRepositoryImpl contribuableRepositoryImpl;
        
     // CREATE 
        public Contribuable createContribuable(Contribuable cont) {
            return contribuableRepository.save(cont);
        }

        // READ
        public List<Contribuable> getContribuables() {
            return contribuableRepository.findAll();
        }
        
        // READ
        public Contribuable getContribuableBySigle(String sigle) {
            return contribuableRepositoryImpl.findBySigle(sigle);
        }
        
        // READ
        @SuppressWarnings("unchecked")
		public List<Contribuable>  getContribuableByRaisonSociale(String ctbNpRs) {
            return (List<Contribuable>) contribuableRepositoryImpl.findByRaisonSociale(ctbNpRs);
        }

        // DELETE
        public void deleteContribuable(Long contId) {
        	contribuableRepository.deleteById(contId);
        }
        
     // UPDATE
        public Contribuable updateContribuable(Long contId, Contribuable contribuableDetails) {
        	Contribuable cont = contribuableRepository.findById(contId).get();
                cont.setCtbNif(contribuableDetails.getCtbNif());
                cont.setCtbRcm(contribuableDetails.getCtbRcm());
                cont.setCtbNpRs(contribuableDetails.getCtbNpRs());
                cont.setCtbBp(contribuableDetails.getCtbBp());
                cont.setCtbCourriel(contribuableDetails.getCtbCourriel());
                cont.setCtbSigle(contribuableDetails.getCtbSigle());
                
                return contribuableRepository.save(cont);                                
        }
}