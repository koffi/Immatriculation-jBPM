package com.rca.immatriculation.contribuable.repository;

import java.util.List;

import com.rca.immatriculation.contribuable.model.Contribuable;

public interface ContribuableCustomRequest {
	
	public Contribuable findBySigle(String ctbSigle);
	public List<Contribuable>  findByRaisonSociale(String ctbNpRs);

}
