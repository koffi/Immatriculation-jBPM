package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "nature")
public class Nature {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="nat_id")
        private Long id;
	
	
	//Code de la nature du contribuable
    @Column(name="nat_code")
    private String natCode;
    
    
    //le libelle de la nature du contribuable
    @Column(name="nat_lib")
    private String natLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the natCode
	 */
	public String getNatCode() {
		return natCode;
	}


	/**
	 * @param natCode the natCode to set
	 */
	public void setNatCode(String natCode) {
		this.natCode = natCode;
	}


	/**
	 * @return the natLib
	 */
	public String getNatLib() {
		return natLib;
	}


	/**
	 * @param natLib the natLib to set
	 */
	public void setNatLib(String natLib) {
		this.natLib = natLib;
	}
    
    

}
