package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "type_personne")
public class TypePersonne {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="typ_prs_id")
        private Long id;
	
	
	//Code de la nature du contribuable
    @Column(name="typ_prs_code")
    private String typPrsCode;
    
    
    //le libelle de la nature du contribuable
    @Column(name="typ_prs_lib")
    private String typPrsLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the typPrsCode
	 */
	public String getTypPrsCode() {
		return typPrsCode;
	}


	/**
	 * @param typPrsCode the typPrsCode to set
	 */
	public void setTypPrsCode(String typPrsCode) {
		this.typPrsCode = typPrsCode;
	}


	/**
	 * @return the typPrsLib
	 */
	public String getTypPrsLib() {
		return typPrsLib;
	}


	/**
	 * @param typPrsLib the typPrsLib to set
	 */
	public void setTypPrsLib(String typPrsLib) {
		this.typPrsLib = typPrsLib;
	}
    
    

}
