package com.rca.immatriculation.contribuable.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "contribuable")
public class Contribuable {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ctb_id")
        private Long id;
    
	//NIF du Contribuable
    @Column(name="ctb_nif")
    private String ctbNif;
    
    
    //RCM du Contribuable
    @Column(name="ctb_rcm")
    private String ctbRcm;
    
    
    //Nom et Prénom ou Raison Sociale du Contribuable
    @Column(name="ctb_np_rs")
    private String ctbNpRs;
    
    
    //Sigle du Contribuable
    @Column(name="ctb_sigle")
    private String ctbSigle;
    
    
    //Date du début de création du Contribuable
    @Column(name="ctb_dat_creat")
    private Date ctbDatCreat;
    
    
    //Lieu de Naissance du Contribuable
    @Column(name="ctb_lieu_nais")
    private String ctbLieuNais;
    
    
    //Boite Postal du Contribuable
    @Column(name="ctb_bp")
    private String ctbBp;
    
    
    //Numéro du téléphone du Contribuable
    @Column(name="ctb_tel")
    private String ctbTel;
    
    
    //Fax du Contribuable
    @Column(name="ctb_fax")
    private String ctbFax;
    
    //Photo du Contribuable
    //@Column(name="ctb_photo")
    //private BufferedImage ctbPhoto;
    
    //courriel du Contribuable
    @Column(name="ctb_courriel")
    private String ctbCourriel;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the ctbNif
	 */
	public String getCtbNif() {
		return ctbNif;
	}

	/**
	 * @param ctbNif the ctbNif to set
	 */
	public void setCtbNif(String ctbNif) {
		this.ctbNif = ctbNif;
	}

	/**
	 * @return the ctbRcm
	 */
	public String getCtbRcm() {
		return ctbRcm;
	}

	/**
	 * @param ctbRcm the ctbRcm to set
	 */
	public void setCtbRcm(String ctbRcm) {
		this.ctbRcm = ctbRcm;
	}

	/**
	 * @return the ctbNpRs
	 */
	public String getCtbNpRs() {
		return ctbNpRs;
	}

	/**
	 * @param ctbNpRs the ctbNpRs to set
	 */
	public void setCtbNpRs(String ctbNpRs) {
		this.ctbNpRs = ctbNpRs;
	}

	/**
	 * @return the ctbSigle
	 */
	public String getCtbSigle() {
		return ctbSigle;
	}

	/**
	 * @param ctbSigle the ctbSigle to set
	 */
	public void setCtbSigle(String ctbSigle) {
		this.ctbSigle = ctbSigle;
	}

	/**
	 * @return the ctbDatCreat
	 */
	public Date getCtbDatCreat() {
		return ctbDatCreat;
	}

	/**
	 * @param ctbDatCreat the ctbDatCreat to set
	 */
	public void setCtbDatCreat(Date ctbDatCreat) {
		
		this.ctbDatCreat = ctbDatCreat;
	}

	/**
	 * @return the ctbLieuNais
	 */
	public String getCtbLieuNais() {
		return ctbLieuNais;
	}

	/**
	 * @param ctbLieuNais the ctbLieuNais to set
	 */
	public void setCtbLieuNais(String ctbLieuNais) {
		this.ctbLieuNais = ctbLieuNais;
	}

	/**
	 * @return the ctbBp
	 */
	public String getCtbBp() {
		return ctbBp;
	}

	/**
	 * @param ctbBp the ctbBp to set
	 */
	public void setCtbBp(String ctbBp) {
		this.ctbBp = ctbBp;
	}

	/**
	 * @return the ctbTel
	 */
	public String getCtbTel() {
		return ctbTel;
	}

	/**
	 * @param ctbTel the ctbTel to set
	 */
	public void setCtbTel(String ctbTel) {
		this.ctbTel = ctbTel;
	}

	/**
	 * @return the ctbCourriel
	 */
	public String getCtbCourriel() {
		return ctbCourriel;
	}

	/**
	 * @param ctbCourriel the ctbCourriel to set
	 */
	public void setCtbCourriel(String ctbCourriel) {
		this.ctbCourriel = ctbCourriel;
	}

	/**
	 * @return the ctbFax
	 */
	public String getCtbFax() {
		return ctbFax;
	}

	/**
	 * @param ctbFax the ctbFax to set
	 */
	public void setCtbFax(String ctbFax) {
		this.ctbFax = ctbFax;
	}
	
	

}