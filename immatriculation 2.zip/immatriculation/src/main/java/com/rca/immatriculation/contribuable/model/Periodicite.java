package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "periodicite")
public class Periodicite {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="per_id")
        private Long id;
	
	
	//Code de la periodicite
    @Column(name="per_code")
    private String perCode;
    
    
   //le libelle de la periodicite
    @Column(name="per_lib")
    private String perLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the perCode
	 */
	public String getPerCode() {
		return perCode;
	}


	/**
	 * @param perCode the perCode to set
	 */
	public void setPerCode(String perCode) {
		this.perCode = perCode;
	}


	/**
	 * @return the perLib
	 */
	public String getPerLib() {
		return perLib;
	}


	/**
	 * @param perLib the perLib to set
	 */
	public void setPerLib(String perLib) {
		this.perLib = perLib;
	}

    
    
}
