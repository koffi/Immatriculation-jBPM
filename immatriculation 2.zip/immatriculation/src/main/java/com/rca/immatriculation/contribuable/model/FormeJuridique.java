package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "forme_juridique")
public class FormeJuridique {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="frj_id")
        private Long id;
	
	
	//Code de la forme juridique
    @Column(name="frj_code")
    private String frjCode;
    
    
   //le libelle de la forme juridique
    @Column(name="frj_lib")
    private String frjLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the frjCode
	 */
	public String getFrjCode() {
		return frjCode;
	}


	/**
	 * @param frjCode the frjCode to set
	 */
	public void setFrjCode(String frjCode) {
		this.frjCode = frjCode;
	}


	/**
	 * @return the frjLib
	 */
	public String getFrjLib() {
		return frjLib;
	}


	/**
	 * @param frjLib the frjLib to set
	 */
	public void setFrjLib(String frjLib) {
		this.frjLib = frjLib;
	}
    
    


}
