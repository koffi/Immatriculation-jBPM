package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "type_impot")
public class TypeImpot {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="type_id")
        private Long id;
	
	
	//Code du type de l'impot
    @Column(name="type_imp_code")
    private String typeImpCode;
    
    
    //le libelle du type  l'impot
    @Column(name="type_imp_lib")
    private String typeImpLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the typeImpCode
	 */
	public String getTypeImpCode() {
		return typeImpCode;
	}


	/**
	 * @param typeImpCode the typeImpCode to set
	 */
	public void setTypeImpCode(String typeImpCode) {
		this.typeImpCode = typeImpCode;
	}


	/**
	 * @return the typeImpLib
	 */
	public String getTypeImpLib() {
		return typeImpLib;
	}


	/**
	 * @param typeImpLib the typeImpLib to set
	 */
	public void setTypeImpLib(String typeImpLib) {
		this.typeImpLib = typeImpLib;
	}
    
    

}
