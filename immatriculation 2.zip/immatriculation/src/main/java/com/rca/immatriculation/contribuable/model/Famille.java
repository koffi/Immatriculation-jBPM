package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "famille")
public class Famille {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="fml_id")
        private Long id;
	
	
	//Le code de l'Activite du contribuable
    @Column(name="fml_act_code")
    private String fmlActCode;
    
    
    //Libelle de l'Activite du contribuable
    @Column(name="fml_act_lib")
    private String fmlActLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the fmlActCode
	 */
	public String getFmlActCode() {
		return fmlActCode;
	}


	/**
	 * @param fmlActCode the fmlActCode to set
	 */
	public void setFmlActCode(String fmlActCode) {
		this.fmlActCode = fmlActCode;
	}


	/**
	 * @return the fmlActLib
	 */
	public String getFmlActLib() {
		return fmlActLib;
	}


	/**
	 * @param fmlActLib the fmlActLib to set
	 */
	public void setFmlActLib(String fmlActLib) {
		this.fmlActLib = fmlActLib;
	}
    
    

}
