package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "type_activite")
public class TypeActivite {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="typ_act_id")
        private Long id;
	
	
	//Le code de l'Activite du contribuable
    @Column(name="typ_act_code")
    private String typActCode;
    
    
    //Libelle de l'Activite du contribuable
    @Column(name="typ_act_lib")
    private String typActLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the typActCode
	 */
	public String getTypActCode() {
		return typActCode;
	}


	/**
	 * @param typActCode the typActCode to set
	 */
	public void setTypActCode(String typActCode) {
		this.typActCode = typActCode;
	}


	/**
	 * @return the typActLib
	 */
	public String getTypActLib() {
		return typActLib;
	}


	/**
	 * @param typActLib the typActLib to set
	 */
	public void setTypActLib(String typActLib) {
		this.typActLib = typActLib;
	}
    
    

}
