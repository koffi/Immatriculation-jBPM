package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
 * 
 * Activite du contribuable
 * ***/

@Entity
@Table(name = "activite")
public class Activite {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="act_id")
        private Long id;
	
	
	//Le code de l'Activite du contribuable
    @Column(name="act_code")
    private String actCode;
    
    
    //Libelle de l'Activite du contribuable
    @Column(name="act_lib")
    private String actLib;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the actCode
	 */
	public String getActCode() {
		return actCode;
	}


	/**
	 * @param actCode the actCode to set
	 */
	public void setActCode(String actCode) {
		this.actCode = actCode;
	}


	/**
	 * @return the actLib
	 */
	public String getActLib() {
		return actLib;
	}


	/**
	 * @param actLib the actLib to set
	 */
	public void setActLib(String actLib) {
		this.actLib = actLib;
	}
    
    

}
