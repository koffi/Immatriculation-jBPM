package com.rca.immatriculation.contribuable.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rca.immatriculation.contribuable.model.Contribuable;
import com.rca.immatriculation.contribuable.service.ContribuableService;



@RestController
@RequestMapping("/api")
public class ContribuableController {
        @Autowired
        ContribuableService contService;
        
        
        @RequestMapping(value="/contribuables", method=RequestMethod.POST)
        public Contribuable createContribuable(@RequestBody Contribuable cont) {
            return contService.createContribuable(cont);
        }
        
        @RequestMapping(value="/contribuables", method=RequestMethod.GET)
        public List<Contribuable> readContribuables() {
            return contService.getContribuables();
        }
        
        @RequestMapping(value="/contribuables/{ctbSigle}", method=RequestMethod.GET)
        public Contribuable readContribuableBySigle(@PathVariable(value = "ctbSigle") String ctbSigle) {
        	return contService.getContribuableBySigle(ctbSigle);
        }
        
        @RequestMapping(value="/contribuables/rs/{ctbNpRs}", method=RequestMethod.GET)
        public List<Contribuable>  readContribuableByRaisonsociale(@PathVariable(value = "ctbNpRs") String ctbNpRs) {
        	return contService.getContribuableByRaisonSociale(ctbNpRs);
        }


        @RequestMapping(value="/contribuables/{contId}", method=RequestMethod.PUT)
        public Contribuable readEmployees(@PathVariable(value = "contId") Long id, @RequestBody Contribuable contDetails) {
            return contService.updateContribuable(id, contDetails);
        }

        @RequestMapping(value="/contribuables/{contId}", method=RequestMethod.DELETE)
        public void deleteContribuables(@PathVariable(value = "contId") Long id) {
        	contService.deleteContribuable(id);
        }

}