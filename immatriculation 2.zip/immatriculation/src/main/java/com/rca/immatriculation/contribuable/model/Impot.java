package com.rca.immatriculation.contribuable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "impot")
public class Impot {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="imp_id")
        private Long id;
	
	
	//Code de l'impot
    @Column(name="imp_code")
    private String impCode;
    
    
  //le libelle de l'impot
    @Column(name="imp_lib")
    private String impLib;
    
    
  //Taux de l'impot
    @Column(name="imp_taux")
    private String impTaux;
    
    
  //taux de penalite de l'impot
    @Column(name="imp_taux_pen")
    private String impTauxPen;


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the impCode
	 */
	public String getImpCode() {
		return impCode;
	}


	/**
	 * @param impCode the impCode to set
	 */
	public void setImpCode(String impCode) {
		this.impCode = impCode;
	}


	/**
	 * @return the impLib
	 */
	public String getImpLib() {
		return impLib;
	}


	/**
	 * @param impLib the impLib to set
	 */
	public void setImpLib(String impLib) {
		this.impLib = impLib;
	}


	/**
	 * @return the impTaux
	 */
	public String getImpTaux() {
		return impTaux;
	}


	/**
	 * @param impTaux the impTaux to set
	 */
	public void setImpTaux(String impTaux) {
		this.impTaux = impTaux;
	}


	/**
	 * @return the impTauxPen
	 */
	public String getImpTauxPen() {
		return impTauxPen;
	}


	/**
	 * @param impTauxPen the impTauxPen to set
	 */
	public void setImpTauxPen(String impTauxPen) {
		this.impTauxPen = impTauxPen;
	}
    
    
    

}
